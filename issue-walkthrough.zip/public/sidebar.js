async function getJSON(url) {
  const resp = await fetch(url);
  if (!resp.ok) {
    alert("Could not load tree data. See console for more details.");
    console.error(await resp.text());
    return [];
  }
  return resp.json();
}

function createTreeNode(id, text, icon, children = false) {
  return { id, text, children, itree: { icon } };
}

async function getHubs() {
  const hubs = await getJSON("/api/hubs");
  return hubs.map((hub) =>
    createTreeNode(`hub|${hub.id}`, hub.attributes.name, "icon-hub", true)
  );
}

async function getHubsList() {
  const hubs = await getJSON("/api/hubs");
  return hubs;
}

async function getProjects(hubId) {
  const projects = await getJSON(`/api/hubs/${hubId}/projects`);
  return projects.map((project) =>
    createTreeNode(
      `project|${hubId}|${project.id}|${project.relationships.issues.data.id}`,
      project.attributes.name,
      "icon-project",
      false
    )
  );
}

async function getProjectsList(hubId) {
  const projects = await getJSON(`/api/hubs/${hubId}/projects`);
  return projects;
}

export async function getProjectsDropdown(hubId) {
  const projects = await getJSON(`/api/hubs/${hubId}/projects`);
  return projects.map((project) =>
    $("#project-list").append(
      $("<option>")
        .val(
          `project|${hubId}|${project.id}|${project.relationships.issues.data.id}`
        )
        .text(project.attributes.name)
    )
  );
}

async function getContents(hubId, projectId, folderId = null) {
  const contents = await getJSON(
    `/api/hubs/${hubId}/projects/${projectId}/contents` +
      (folderId ? `?folder_id=${folderId}` : "")
  );
  return contents.map((item) => {
    if (item.type === "folders") {
      return createTreeNode(
        `folder|${hubId}|${projectId}|${item.id}`,
        item.attributes.displayName,
        "icon-my-folder",
        true
      );
    } else {
      return createTreeNode(
        `item|${hubId}|${projectId}|${item.id}`,
        item.attributes.displayName,
        "icon-item",
        true
      );
    }
  });
}

async function getFolderContents(hubId, projectId, folderId = null) {
  const contents = await getJSON(
    `/api/hubs/${hubId}/projects/${projectId}/contents` +
      (folderId ? `?folder_id=${folderId}` : "")
  );

  return contents;
}

async function getVersions(hubId, projectId, itemId) {
  const versions = await getJSON(
    `/api/hubs/${hubId}/projects/${projectId}/contents/${itemId}/versions`
  );
  return versions.map((version) =>
    createTreeNode(
      `version|${version.id}`,
      version.attributes.createTime,
      "icon-version"
    )
  );
}

export async function getItemVersions(hubId, projectId, itemId) {}

export async function getVersionsList(hubId, projectId, itemId) {
  const versions = await getJSON(
    `/api/hubs/${hubId}/projects/${projectId}/contents/${itemId}/versions`
  );
  return versions;
}

export function initTree(selector, onSelectionChanged) {
  // See http://inspire-tree.com
  const tree = new InspireTree({
    data: function (node) {
      if (!node || !node.id) {
        return getHubs();
      } else {
        const tokens = node.id.split("|");
        switch (tokens[0]) {
          case "hub":
            return getProjects(tokens[1]);
          //case 'project': return getContents(tokens[1], tokens[2]);
          //case 'folder': return getContents(tokens[1], tokens[2], tokens[3]);
          //case 'item': return getVersions(tokens[1], tokens[2], tokens[3]);
          default:
            return [];
        }
      }
    },
    selection: {
      allow: true,
    },
  });
  tree.on("node.click", function (event, node) {
    event.preventTreeDefault();
    const tokens = node.id.split("|");

    if (tokens[0] === "project") {
      onSelectionChanged(tokens[2], tokens[3]);
    }
  });
  return new InspireTreeDOM(tree, { target: selector });
}

// export async function initProjectDropdown(selector) {
//   const hubs = await getHubsList();

//   hubs.map(async (hub) => {
//     $(selector).append(`<optgroup label="${hub.attributes.name}">`);

//     const projects = await getProjectsList(hub.id);
//     projects.map(async (project) => {
//       const folders = await getFolderContents(hub.id, project.id);

//       $(selector).append(`<optgroup label="${project.attributes.name}">`);

//       const projectFilesFolder = folders[0];
//       const items = await getFolderContents(
//         hub.id,
//         project.id,
//         projectFilesFolder.id
//       );
//       const itemFilter = items.filter((item) => item.type === "items");
//       itemFilter.map((item) => {
//         $(selector)
//           .append(`<option value="project|${hub.id}|${project.id}|${project.relationships.issues.data.id}">
//                     &nbsp;&nbsp;&nbsp;${item.attributes.displayName}
//                   </option>`);
//       });

//       $(selector).append(`</optgroup>`);
//     });
//     $(selector).append(`</optgroup>`);
//   });
// }

export async function getThumbnails(urn) {
  const seedUrn = window.btoa(urn).replace(/=/g, "");
  const thumbnail = await getJSON(`/api/thumbnail/${seedUrn}`);

  return thumbnail;
}

export async function initProjectDropdown(selector) {
  const hubs = await getHubsList();
  const mainHub = hubs[0];

  const projects = await getProjectsList(mainHub.id);

  $.each(projects, async (index, project) => {
    //  console.log('PROJECT', project, value);
    var optgroup = $("<optgroup>");
    optgroup.attr("label", project.attributes.name);

    const folders = await getFolderContents(mainHub.id, project.id);
    const mainFolder = folders[0];
    const items = await getFolderContents(
      mainHub.id,
      project.id,
      mainFolder.id
    );
    const itemFilter = items.filter((item) => item.type === "items");
    await $.each(itemFilter, async (index, item) => {
      const versionList = await getVersionsList(
        mainHub.id,
        project.id,
        item.id
      );
      const latestVersion = versionList[0];

      var option = $("<option></option>");
      option.val(
        `project|${mainHub.id}|${project.id}|${
          project.relationships.issues.data.id
        }|${item.id}|${project.relationships.issues.data.id}|${
          latestVersion.id
        }|${JSON.stringify(latestVersion)}|${JSON.stringify(item)}`
      );
      option.text(item.attributes.displayName);

      optgroup.append(option);
    });

    $(selector).append(optgroup);
  });

  return projects;
}

export async function initial_project_list() {
  const hubs = await getHubsList();
  const mainHub = hubs[0];
  const projects = await getProjectsList(mainHub.id);

  $.each(projects, async (index, project) => {
    //  console.log('PROJECT', project, value);
    const accordionItem = $("<div>");
    accordionItem.attr('class', 'accordion-item')
    
    const folders = await getFolderContents(mainHub.id, project.id);
    
    const mainFolder = folders[0];
    const items = await getFolderContents(
      mainHub.id,
      project.id,
      mainFolder.id
    );
    const itemFilter = items.filter((item) => item.type === "items");
    $.each(itemFilter, async (index, item) => {
      const versionList = await getVersionsList(
        mainHub.id,
        project.id,
        item.id
      );
      const latestVersion = versionList[0];
      accordionItem.append();
      accordionItem.innerHTML = `<h2 class="accordion-header" id="heading${project.id}">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#${project.id}" aria-expanded="true" aria-controls="collapseOne">
                                    ${project.attributes.name}
                                   </button>
                                  </h2>
     <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
     <div class="accordion-body">
            This is the content for the first item. You can include any HTML here.
     </div>
     </div>`

      const thumbnail = await getThumbnails(item.id);

      console.log({ project, thumbnail });
    });
  });

  return projects;
}
