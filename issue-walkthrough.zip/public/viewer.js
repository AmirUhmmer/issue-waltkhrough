/// import * as Autodesk from "@types/forge-viewer";
//import { getIssues } from "../routes/services/issues";
import { getAllIssues } from "./issues.js";
var viewer = null;
var pushpinData = null;
var selectedProject = null;
var selectedProjectItem = null;
var pushpinExt = null;
var viewerPushPinExt = null;

async function getAccessToken(callback) {
  try {
    const resp = await fetch("/api/auth/token");
    if (!resp.ok) {
      throw new Error(await resp.text());
    }
    const { access_token, expires_in } = await resp.json();
    callback(access_token, expires_in);
  } catch (err) {
    alert("Could not obtain access token. See the console for more details.");
    console.error(err.message);
  }
}

export function initViewer(container) {
  return new Promise(function (resolve, reject) {
    Autodesk.Viewing.Initializer({ getAccessToken }, async function () {
      const v = new Autodesk.Viewing.GuiViewer3D(container);
      v.start();
      v.setTheme("light-theme");
      viewer = v;
      resolve(v);
    });
  });

}

export function loadModel(urn, guid) {
  function onDocumentLoadSuccess(doc) {
    var viewables = guid
      ? doc.getRoot().findByGuid(guid)
      : doc.getRoot().getDefaultGeometry();
    viewer.loadDocumentNode(doc, viewables);
    viewer.addEventListener(
      Autodesk.Viewing.GEOMETRY_LOADED_EVENT,
      onGeometryLoaded
    );
  }
  function onDocumentLoadFailure(code, message) {
    alert("Could not load model. See console for more details.");
    console.error(message);
  }
  Autodesk.Viewing.Document.load(
    "urn:" + urn,
    onDocumentLoadSuccess,
    onDocumentLoadFailure
  );
}

export function loadInitialModel(viewer, item, projectId) {
  function onDocumentLoadSuccess(doc) {
    selectedProjectItem = item;
    selectedProject = projectId;

    viewer.loadDocumentNode(doc, doc.getRoot().getDefaultGeometry());
    viewer.addEventListener(
      Autodesk.Viewing.GEOMETRY_LOADED_EVENT,
      onInitialGeometryLoaded
    );
  }
  function onDocumentLoadFailure(code, message) {
    alert("Could not load model. See console for more details.");
    console.error(message);
  }
  const urn = window.btoa(item.id).replace(/=/g, "");
  Autodesk.Viewing.Document.load(
    "urn:" + urn,
    onDocumentLoadSuccess,
    onDocumentLoadFailure
  );
}

export async function setPushpinData(v) {
  pushpinData = v;
}

export async function createPushPins(v, issue) {
  var pushpinExtension = await viewer.loadExtension(
    "Autodesk.BIM360.Extension.PushPin"
  );
  pushpinExtension.removeAllItems();
  pushpinExtension.showAll();

  const pushpin = [];

  if (issue.sheetGuid !== viewer.selectedItem.guid()) {
    var viewable = viewer.bubble.search({ guid: issue.sheetGuid }); // get sheet by guid
    if (!viewable.length) {
      return console.error("Sheet could not be found.");
    }
    // Select sheet to display (callbacks are the same as in `onDocumentLoadSuccess`)
    viewer.selectItem(viewable[0], onItemLoadSuccess, onItemLoadFail);
    // To highlight this pushpin in the sheet, use this function `PushPinExtensionHandle.selectOne(issue_id);` within the `onItemLoadSuccess` function.
  } else {
    // If the pushpin is in the current sheet, select the pushpin
    pushpinExtension.selectOne(issue.id);
    pushpin.push(v);

    pushpinExtension.loadItemsV2(pushpin);
    pushpinExtension.selectOne(v.id);
  }
}

export async function pushpin_SelectOne(issueId, pushpin) {
  var pushpinExtension = await viewer.loadExtension(
    "Autodesk.BIM360.Extension.PushPin"
  );
  // var pa = [];
  // pa.push(pushpin);

  //pushpinExtension.loadItemsV2(pa);
  pushpinExtension.selectOne(issueId);
}

async function onGeometryLoaded(evt) {
  //load extension of pushpin
  //remove last items collection
  var pushpinExtension = await viewer.loadExtension(
    "Autodesk.BIM360.Extension.PushPin"
  );
  pushpinExtension.removeAllItems();
  pushpinExtension.showAll();

  var pushpin = [];
  pushpin.push({
    type: "issues",
    id: pushpinData.id,
    label: pushpinData.title,
    status: pushpinData.status,
    position: pushpinData.position,
    objectId: pushpinData.objectId,
    viewerState: pushpinData.viewerState,
  });
  pushpinExtension.loadItemsV2(pushpin);
  pushpinExtension.selectOne(pushpinData.id);
}

async function onInitialGeometryLoaded(evt) {
  //load extension of pushpin
  //remove last items collection

  pushpinExt = await viewer.loadExtension("Autodesk.BIM360.Extension.PushPin");

  pushpinExt.pushPinManager.addEventListener("pushpin.created", function (e) {
    pushpinExt.endCreateItem();
    console.log({ e });
    const newIssue = e.value.itemData;
    $("#txt-pushpindata").val(JSON.stringify(newIssue));
    $("#frm-issues-modal").modal("show");

    //console.log(viewer.selectedItem);
  });

  const fasIcon = document.createElement("i");

  pushpinExt.pushPinManager.addEventListener("pushpin.selected", function (e) {
    console.log(e);
    const pushPinItem = e.value;
    const pushPinList = e.target.pushPinList;
    fasIcon.className = "";
    fasIcon.style.fontSize = "";

    pushPinList.forEach((pushpin) => {
      const unselectedPusPinsDiv = document.getElementById(pushpin.itemData.id);
      unselectedPusPinsDiv.backgroundImage = "";
    });

   // const pushpindiv = document.getElementById(pushPinItem.itemData.id);
   // pushpindiv.style.backgroundImage = "";
  });

  pushpinExt.removeAllItems();
  pushpinExt.showAll();

  const filter = {
    "filter[linkedDocumentUrn]": selectedProjectItem.relationships.item.data.id,
  };

  const allIssues = await getAllIssues(selectedProject, filter);

  //console.log({ allIssues });

  var pushpin = [];

  //  await populateIssueList('#issue-list', allIssues)
  $.each(allIssues, (index, issue) => {
    //  console.log(issue);
    const pushpinDetails =
      issue.linkedDocuments.length > 0
        ? issue.linkedDocuments[0].details
        : null;

    if (pushpinDetails) {
      pushpin.push({
        type: "issues",
        id: issue.id,
        label: issue.title,
        status: issue.status,
        position: pushpinDetails.position,
        objectId: pushpinDetails.objectId,
        viewerState: pushpinDetails.viewerState,
      });
    }
  });
  pushpinExt.loadItemsV2(pushpin);

  $("#btn-create-issue").attr("disabled", false);
}

export async function startCreatePushPin() {
  alert("Click on one of the object in the Viewer");
  pushpinExt.startCreateItem({ label: "New", status: "open", type: "issues" });
}
