import { initViewer, loadModel, setPushpinData } from "../../viewer.js";

try {
  const viewer = initViewer(document.getElementById("preview"));
  const params = new URLSearchParams(window.location.search);

  const containerId = params.get("containerId");
  const issueId = params.get("issueId");
  
  const issue = await fetch(
    `/api/issue/${containerId}/${issueId}`
  );

  const issue_details = await issue.json();
  const linkedDocument = issue_details.linkedDocuments[0];
  const viewable = linkedDocument.details.viewable;
  const viewerState = linkedDocument.details.viewerState;
 // console.log(issue_details);
  await setPushpinData({
    id: issue_details.id,
    title: issue_details.title,
    status: issue_details.status,
    position: linkedDocument.details.position,
    objectId: linkedDocument.details.objectId,
    viewerState: viewerState,
  });
  await loadModel(viewerState.seedURN, viewable.guid);
 // console.log(issue_details);
} catch (err) {
  alert("error displaying application");
  console.log(err);
}
