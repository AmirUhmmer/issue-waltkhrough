const { ok } = require('assert');
const config = require('../../config');  
const { get, post, patch, put,getBinary } = require('./fetch_common');  
const axios = require('axios')  
const fs = require('fs');
const path = require('path');



async function getThumbnail(urn, size) {
  try {
    let endpoint = config.endpoints.modelDerivative.thumbnail.format(urn) + `?width=${size.width}&height=${size.height}`
    //apply with filters
    const headers = config.endpoints.httpHeaders(config.credentials.token_3legged)
    const response = await get(endpoint, headers)

    console.log(response);
    if (response.results && response.results.length > 0) {
      console.log(`getting thumbnail for urn ${urn}`)
     

    } else {
      return allIssues
    }
  } catch (e) {
    console.error(`getting thumbnail for  ${urn} failed: ${e}`)
    return {}
  }
}


module.exports = {
  getThumbnail
}