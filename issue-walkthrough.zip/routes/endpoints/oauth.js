

const express = require("express");

const {
  getAuthorizationUrl,
  authCallbackMiddleware,
  authRefreshMiddleware,
  getUserProfile,
} = require("../services/oauth");

let router = express.Router();

router.get("/api/auth/login", function (req, res) {
  res.redirect(getAuthorizationUrl());
});

router.get("/api/auth/redirect-url", function (req, res) {
  res.json({ redirectUrl: getAuthorizationUrl() });
});

router.get("/api/auth/logout", function (req, res) {
  req.session = null;
  res.redirect("/");
});

router.get("/api/auth/callback", authCallbackMiddleware, function (req, res) {
  //res.redirect("/");
  const publicToken = req.session.public_token;
  const refreshToken = req.session.refresh_token;
  const expires_at = req.session.expires_at;
  const internal_token = req.session.internal_token;
 
     // window.opener.postMessage({ token: '${publicToken}' }, window.location.origin);
 
    res.send(`
        <script>
            if (window.opener) {
                // Send the token back to the parent window
               
                window.opener.postMessage({ token: '${publicToken}', refreshToken: '${refreshToken}', expires_at: '${expires_at}', internal_token: '${internal_token}' }, window.location.origin);
 
                window.close();  // Close the popup
            }
        </script>
    `);
});

router.get("/api/auth/token", authRefreshMiddleware, function (req, res) {
  res.json(req.publicOAuthToken);
});


router.get(
  "/api/auth/profile",
  authRefreshMiddleware,
  async function (req, res, next) {
    try {
      const profile = await getUserProfile(req.internalOAuthToken);
      //   console.log('PROFILE', profile);
      res.json({ name: `${profile.family_name}, ${profile.given_name}` });
    } catch (err) {
      next(err.data);
    }
  }
);

module.exports = router;
