const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");
const multer = require("multer");
const formidable = require("formidable");

const config = require("../../config");
const { authRefreshMiddleware } = require("../services/oauth");
const model_derivative_services = require("../services/modelderivative");

router.get(
  "/api/thumbnail/:urn",
  authRefreshMiddleware,
  async (req, res) => {
    config.credentials.token_3legged = req.internalOAuthToken.access_token;

    try {
      const { urn } = req.params;
      
      const {height, width } = req.query;
      const size = height ? ({height : height , width: height}) : (width ? {height: width, width: width} : {height: 40, width: 40});

      //get issues collection with the filter
      const thumbnail = await model_derivative_services.getThumbnail(urn, size);


      res.json(thumbnail);
    } catch (err) {
      console.log(`/api/thumbnail/urn`, err);
      res.status(500).end;
    }
  }
);


module.exports = router;